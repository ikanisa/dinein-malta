import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassCard } from '../components/GlassCard';
import { VenueListSkeleton } from '../components/Loading';
import { getAllVenues, toggleFavoriteVenue, getMyProfile } from '../services/mockDatabase';
import { getAiRecommendation } from '../services/geminiService';
import { Venue } from '../types';

const ClientExplore = () => {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [aiMode, setAiMode] = useState(false);
  const [aiResponse, setAiResponse] = useState<{text: string, chunks: any[] | undefined} | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const [fetchedVenues, profile] = await Promise.all([
        getAllVenues(),
        getMyProfile()
      ]);
      setVenues(fetchedVenues);
      setFavorites(profile.favorites);
      setLoading(false);
    };
    fetchData();
  }, []);

  const handleToggleFav = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const newFavs = await toggleFavoriteVenue(id);
    setFavorites(newFavs);
  };

  const getUserLocation = (): Promise<{lat: number, lng: number} | undefined> => {
      return new Promise((resolve) => {
          if (!navigator.geolocation) {
              resolve(undefined);
          } else {
              navigator.geolocation.getCurrentPosition(
                  (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
                  (err) => {
                      console.log("Location denied for concierge", err);
                      resolve(undefined);
                  },
                  { timeout: 5000 }
              );
          }
      });
  };

  const handleAiSearch = async () => {
      if (!searchTerm) return;
      setAiLoading(true);
      setAiMode(true);
      
      const loc = await getUserLocation();
      const result = await getAiRecommendation(searchTerm, loc);
      setAiResponse(result);
      setAiLoading(false);
  };

  const filteredVenues = venues.filter(v => 
    v.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    v.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 pb-24 space-y-6 animate-fade-in pt-safe-top">
       <header>
         <h1 className="text-3xl font-bold mb-1">Explore</h1>
         <p className="text-muted">Discover the finest liquid spots.</p>
       </header>

       {/* Search Bar / AI Concierge */}
       <div className="relative">
         <span className="absolute left-3 top-3 text-muted">✨</span>
         <input 
           type="text" 
           placeholder="Try: 'Romantic dinner in Sliema'..." 
           className="w-full bg-surface border border-border rounded-xl py-3 pl-10 pr-12 text-foreground focus:outline-none focus:border-purple-500 transition-colors"
           value={searchTerm}
           onChange={e => { setSearchTerm(e.target.value); if(e.target.value === '') setAiMode(false); }}
           onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()}
         />
         <button 
            onClick={handleAiSearch}
            className="absolute right-2 top-2 bg-purple-600/80 p-1.5 rounded-lg text-xs font-bold text-white"
         >
             GO
         </button>
       </div>

       {/* AI Results Section */}
       {aiMode && (
           <div className="animate-fade-in">
               <h3 className="font-bold text-purple-400 mb-2">Virtual Concierge</h3>
               {aiLoading ? (
                   <div className="p-8 text-center text-muted animate-pulse">Finding the best options...</div>
               ) : (
                   <GlassCard className="bg-purple-900/10 border-purple-500/30">
                       <div className="text-sm whitespace-pre-line mb-4 text-foreground">{aiResponse?.text}</div>
                       
                       {/* Grounding Sources (Google Maps) */}
                       {aiResponse?.chunks && aiResponse.chunks.length > 0 && (
                           <div className="border-t border-border pt-3 mt-2">
                               <div className="text-xs text-muted mb-2 uppercase font-bold tracking-wider">Sources (Google Maps)</div>
                               <div className="flex flex-wrap gap-2">
                                   {aiResponse.chunks.map((chunk, idx) => {
                                       const webUri = chunk.web?.uri;
                                       const title = chunk.web?.title || "Map Link";
                                       if (!webUri) return null;
                                       return (
                                           <a 
                                             key={idx} 
                                             href={webUri} 
                                             target="_blank" 
                                             rel="noreferrer"
                                             className="px-3 py-1 bg-surface-highlight rounded-full text-xs hover:bg-white/10 flex items-center gap-1 text-foreground"
                                           >
                                               📍 {title}
                                           </a>
                                       );
                                   })}
                               </div>
                           </div>
                       )}
                   </GlassCard>
               )}
               <div className="border-b border-border my-6"></div>
           </div>
       )}

       {/* Categories (Static for now) */}
       {!aiMode && (
         <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
           {['All', 'Bars', 'Restaurants', 'Clubs', 'Beach'].map(cat => (
             <button 
               key={cat}
               className="px-4 py-2 bg-surface rounded-full text-xs font-bold whitespace-nowrap hover:bg-surface-highlight text-muted hover:text-foreground transition-colors"
             >
               {cat}
             </button>
           ))}
         </div>
       )}

       <div className="grid gap-4">
         {loading && !aiMode && [1, 2, 3, 4, 5, 6].map(i => <VenueListSkeleton key={i} />)}
         
         {!loading && !aiMode && filteredVenues.map(venue => (
           <GlassCard key={venue.id} onClick={() => navigate(`/menu/${venue.id}`)} className="group bg-surface border-border">
              <div className="flex justify-between items-start mb-2">
                 <h3 className="font-bold text-lg text-foreground">{venue.name}</h3>
                 <button onClick={(e) => handleToggleFav(e, venue.id)} className="text-xl">
                   {favorites.includes(venue.id) ? '❤️' : '🤍'}
                 </button>
              </div>
              <p className="text-xs text-muted mb-2">{venue.address}</p>
              <div className="flex items-center gap-2 text-xs">
                 <span className="bg-blue-500/20 text-blue-300 px-2 py-1 rounded">⭐ 4.8</span>
                 <span className="text-muted">•</span>
                 <span className="text-muted">Bar & Grill</span>
              </div>
           </GlassCard>
         ))}
         {!loading && !aiMode && filteredVenues.length === 0 && (
           <div className="text-center text-muted py-10">No venues found.</div>
         )}
       </div>
    </div>
  );
};

export default ClientExplore;