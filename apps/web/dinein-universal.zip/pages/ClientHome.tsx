import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { GlassCard } from '../components/GlassCard';
import { CardSkeleton, Spinner } from '../components/Loading';
import { PullToRefresh } from '../components/PullToRefresh';
import { createReservation, getAllVenues } from '../services/mockDatabase';
import { findNearbyPlaces, discoverGlobalVenues, generateVenueThumbnail, adaptUiToLocation, getVenueInsights } from '../services/geminiService';
import { Venue, UIContext } from '../types';

const NearbyVenueCard = ({ place, index, registeredVenue, currency, insight }: { place: any, index: number, registeredVenue?: Venue, currency: string, insight?: string }) => {
    const [imageUrl, setImageUrl] = useState<string | null>(registeredVenue?.imageUrl || null);
    const [loadingImage, setLoadingImage] = useState(!registeredVenue?.imageUrl);
    const navigate = useNavigate();

    useEffect(() => {
        let mounted = true;
        const fetchImage = async () => {
            if (registeredVenue?.imageUrl) return; 
            
            // Lazy load visuals - only if in view (simulated by index stagger for now)
            const staggerDelay = index < 2 ? 0 : (index * 200) + (Math.random() * 300);
            if (staggerDelay > 0) await new Promise(r => setTimeout(r, staggerDelay));
            if (!mounted) return;

            const img = await generateVenueThumbnail(place.name, place.visualVibe);
            if (mounted) {
                if (img) setImageUrl(img);
                setLoadingImage(false);
            }
        };
        fetchImage();
        return () => { mounted = false; };
    }, [place.name, place.visualVibe, index, registeredVenue]);

    const whatsappLink = (registeredVenue?.whatsappNumber || place.phoneNumber)
        ? `https://wa.me/${(registeredVenue?.whatsappNumber || place.phoneNumber).replace(/[^0-9]/g, '')}`
        : null;
    
    const isVerified = !!registeredVenue;
    const activeCurrency = registeredVenue?.currency || currency;

    return (
        <div className="w-full mb-6 group relative animate-slide-up" style={{ animationDelay: '0.1s' }}>
             <div 
                className={`glass-panel overflow-hidden rounded-3xl border-0 shadow-lg bg-surface transition-transform ${isVerified ? 'cursor-pointer active:scale-[0.98]' : ''}`}
                onClick={() => isVerified && navigate(`/menu/${registeredVenue.id}`)}
             >
                 <div className="aspect-[4/3] w-full bg-gray-900 relative">
                     {loadingImage ? (
                         <div className="w-full h-full animate-pulse bg-surface-highlight flex items-center justify-center">
                             <span className="text-xs text-muted font-medium">Loading Visual...</span>
                         </div>
                     ) : (
                         <img 
                            src={imageUrl || `https://via.placeholder.com/600x400?text=${place.name}`} 
                            alt={place.name} 
                            className="w-full h-full object-cover" 
                         />
                     )}
                     
                     <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-90" />
                     
                     {/* Insight Badge (Events/Happy Hours) */}
                     {insight && (
                         <div className="absolute top-4 left-4 z-20">
                             <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-3 py-1.5 rounded-full text-[10px] font-bold text-white border border-white/20 shadow-glow animate-pulse flex items-center gap-1.5">
                                 <span>🔥</span>
                                 {insight}
                             </div>
                         </div>
                     )}
                     
                     <div className="absolute top-4 right-4 flex gap-2">
                         {isVerified && (
                             <div className="bg-blue-600 px-3 py-1 rounded-full text-xs font-bold text-white border border-white/10 flex items-center gap-1 shadow-glow">
                                 ✓ Verified
                             </div>
                         )}
                         <div className="bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-xs font-bold text-white border border-white/10 flex items-center gap-1">
                             <span className="text-yellow-400">★</span> 
                             {place.rating || 'New'}
                             {place.userRatingCount && <span className="text-gray-400 ml-1">({place.userRatingCount})</span>}
                         </div>
                     </div>

                     <div className="absolute bottom-0 left-0 right-0 p-5">
                         <h3 className="font-bold text-white text-2xl leading-none mb-2">{place.name}</h3>
                         <div className="flex items-center gap-2 text-sm text-gray-300 font-medium">
                             <span>{place.category}</span>
                             <span className="w-1 h-1 bg-gray-500 rounded-full" />
                             <span>{place.priceLevel?.replace('$', activeCurrency).replace('€', activeCurrency) || activeCurrency}</span>
                             <span className="w-1 h-1 bg-gray-500 rounded-full" />
                             <span>{place.distance}</span>
                         </div>
                     </div>
                 </div>

                 <div className="p-3 bg-surface-highlight backdrop-blur-md flex gap-2" onClick={e => e.stopPropagation()}>
                     {isVerified && (
                        <button 
                            onClick={() => navigate(`/menu/${registeredVenue.id}`)}
                            className="flex-[2] py-3 bg-foreground text-background rounded-xl text-sm font-bold flex items-center justify-center gap-2 active:scale-95 transition-transform shadow-lg"
                        >
                             🍽️ View Menu
                        </button>
                     )}
                     
                     {whatsappLink ? (
                         <a 
                            href={whatsappLink} 
                            target="_blank" 
                            rel="noreferrer" 
                            className={`flex-1 py-3 bg-[#25D366]/20 border border-[#25D366]/30 rounded-xl text-sm font-bold text-[#25D366] flex items-center justify-center gap-2 active:scale-95 transition-transform ${!isVerified ? 'flex-[1]' : ''}`}
                         >
                            <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                            </svg>
                         </a>
                     ) : null}

                     <a 
                        href={place.googleMapsUrl} 
                        target="_blank" 
                        rel="noreferrer" 
                        className={`flex-1 py-3 bg-surface-highlight border border-border rounded-xl text-sm font-bold text-foreground flex items-center justify-center gap-2 active:scale-95 transition-transform ${!isVerified ? 'flex-[1]' : ''}`}
                     >
                         <span className="text-xl">📍</span>
                     </a>
                 </div>
             </div>
        </div>
    );
};


const ClientHome = () => {
  const [categorizedVenues, setCategorizedVenues] = useState<Record<string, any[]>>({});
  const [allFetchedVenues, setAllFetchedVenues] = useState<any[]>([]);
  const [registeredVenues, setRegisteredVenues] = useState<Venue[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [locationStatus, setLocationStatus] = useState<string>('prompt');
  const [userPos, setUserPos] = useState<{lat: number, lng: number} | null>(null);
  
  const [showLocationModal, setShowLocationModal] = useState(false);
  
  const [uiContext, setUiContext] = useState<UIContext>({ 
      appName: 'DineIn', 
      greeting: 'Welcome', 
      currencySymbol: '$' 
  });
  
  const [venueInsights, setVenueInsights] = useState<Record<string, string>>({});

  const MAX_VENUES = 50;
  const CACHE_KEY_VENUES = 'dinein_cached_venues_list';
  const CACHE_KEY_CTX = 'dinein_cached_ui_context';

  useEffect(() => {
    initDiscovery();
  }, []);

  // Update grouped list whenever flat list changes
  useEffect(() => {
      const grouped: Record<string, any[]> = {};
      allFetchedVenues.forEach(place => {
          const cat = place.category || 'Trending';
          if (!grouped[cat]) grouped[cat] = [];
          grouped[cat].push(place);
      });
      setCategorizedVenues(grouped);

      // Async fetch insights for top venues if we have location
      if (allFetchedVenues.length > 0 && userPos) {
          const topNames = allFetchedVenues.slice(0, 10).map(v => v.name);
          // Check if we need insights
          const missingInsights = topNames.filter(n => !venueInsights[n]);
          if (missingInsights.length > 0) {
              getVenueInsights(missingInsights, userPos.lat, userPos.lng).then(newInsights => {
                  setVenueInsights(prev => ({...prev, ...newInsights}));
              });
          }
      }
  }, [allFetchedVenues, userPos]);

  const initDiscovery = async () => {
      setLoading(true);

      // 1. Fetch Registered Venues from Supabase (DB)
      const dbVenues = await getAllVenues();
      setRegisteredVenues(dbVenues);

      // 2. Check Local Cache for Venues & Context
      const cachedList = localStorage.getItem(CACHE_KEY_VENUES);
      const cachedCtx = localStorage.getItem(CACHE_KEY_CTX);
      
      if (cachedList) {
          try {
              setAllFetchedVenues(JSON.parse(cachedList));
              if (cachedCtx) setUiContext(JSON.parse(cachedCtx));
              setLoading(false);
              // Background Refresh if desired, or simple cache strategy: use cache if exists
              return; 
          } catch(e) { localStorage.removeItem(CACHE_KEY_VENUES); }
      }

      // 3. New Discovery if no cache
      // Do NOT auto-request. Load global fallback first, then ask nicely.
      const fallback = await discoverGlobalVenues();
      setAllFetchedVenues(fallback);
      setLoading(false);
      
      // Trigger the explanation modal instead of browser prompt
      setShowLocationModal(true);
  };

  const handleManualRefresh = async () => {
      // Force refresh data ignoring cache
      if (userPos) {
           const [discovered, context] = await Promise.all([
              findNearbyPlaces(userPos.lat, userPos.lng),
              adaptUiToLocation(userPos.lat, userPos.lng)
           ]);
           setAllFetchedVenues(discovered);
           setUiContext(context);
           localStorage.setItem(CACHE_KEY_VENUES, JSON.stringify(discovered));
      } else {
           await initDiscovery();
      }
  };

  const requestLocationAndFetch = () => {
      if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
              async (pos) => {
                  setLocationStatus('granted');
                  setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
                  
                  // Parallel adaptation and discovery
                  const [discovered, context] = await Promise.all([
                      findNearbyPlaces(pos.coords.latitude, pos.coords.longitude),
                      adaptUiToLocation(pos.coords.latitude, pos.coords.longitude)
                  ]);
                  
                  setUiContext(context);
                  localStorage.setItem(CACHE_KEY_CTX, JSON.stringify(context));
                  
                  // Save initial batch
                  setAllFetchedVenues(discovered);
                  localStorage.setItem(CACHE_KEY_VENUES, JSON.stringify(discovered));
                  
                  setLoading(false);
              },
              async (err) => {
                  console.log("Loc permission denied", err);
                  setLocationStatus('denied');
                  // Fallback already loaded (global), just ensure loading is off
                  setLoading(false);
              }
          );
      } else {
          setLocationStatus('unsupported');
      }
  };

  const handleLoadMore = async () => {
      if (!userPos || allFetchedVenues.length >= MAX_VENUES || loadingMore) return;
      
      setLoadingMore(true);
      const currentNames = allFetchedVenues.map(v => v.name);
      
      const newBatch = await findNearbyPlaces(userPos.lat, userPos.lng, currentNames);
      
      if (newBatch.length > 0) {
          const updatedList = [...allFetchedVenues, ...newBatch];
          setAllFetchedVenues(updatedList);
          localStorage.setItem(CACHE_KEY_VENUES, JSON.stringify(updatedList));
      }
      
      setLoadingMore(false);
  };

  const requestLocation = () => {
      setShowLocationModal(false);
      setLoading(true);
      requestLocationAndFetch();
  };

  const getRegisteredMatch = (place: any) => {
      return registeredVenues.find(v => 
          v.name.toLowerCase().includes(place.name.toLowerCase()) || 
          place.name.toLowerCase().includes(v.name.toLowerCase())
      );
  };

  const hasMore = allFetchedVenues.length < MAX_VENUES && locationStatus === 'granted';

  return (
    <div className="min-h-screen pt-safe-top transition-colors duration-1000 relative">
      
      {/* Location Explanation Modal */}
      {showLocationModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm animate-fade-in">
              <GlassCard className="max-w-sm w-full p-8 text-center space-y-5 border-blue-500/30 shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-purple-500"></div>
                  
                  <div className="w-20 h-20 bg-blue-500/10 text-blue-400 rounded-full flex items-center justify-center mx-auto text-4xl mb-2 animate-bounce">
                      📍
                  </div>
                  
                  <div>
                      <h2 className="text-2xl font-bold text-foreground mb-2">Discover Local Gems</h2>
                      <p className="text-sm text-muted leading-relaxed">
                          DineIn uses your location to show menus and venues directly around you.
                      </p>
                  </div>
                  
                  <div className="flex flex-col gap-3 pt-2">
                      <button 
                        onClick={requestLocation}
                        className="w-full py-3.5 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow-lg shadow-blue-900/20 active:scale-95 transition-transform"
                      >
                          Enable Location
                      </button>
                      <button 
                        onClick={() => setShowLocationModal(false)}
                        className="text-xs text-muted hover:text-foreground font-medium py-2"
                      >
                          No thanks, I'll browse manually
                      </button>
                  </div>
              </GlassCard>
          </div>
      )}

      {/* Sticky Native Header */}
      <div className="sticky top-0 z-40 px-6 pt-12 pb-4 bg-glass border-b border-glassBorder backdrop-blur-xl transition-all">
        <div className="flex justify-between items-end">
            <div>
                <p className="text-xs font-bold text-muted uppercase tracking-widest mb-1 animate-fade-in">
                    {locationStatus === 'granted' ? uiContext.greeting : 'Discover'}
                </p>
                <h1 className="text-3xl font-bold text-foreground tracking-tight animate-fade-in">
                  {uiContext.appName}
                </h1>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 p-0.5">
                <div className="w-full h-full rounded-full bg-surface flex items-center justify-center font-bold text-xs text-foreground">
                    ME
                </div>
            </div>
        </div>
      </div>
      
      <PullToRefresh onRefresh={handleManualRefresh}>
        <div className="px-4 pt-6 pb-32 space-y-8 min-h-[80vh]">
            
            {/* Persistent Location Request Card - If user is in manual mode */}
            {!loading && locationStatus !== 'granted' && !showLocationModal && (
                <GlassCard className="bg-blue-900/10 border-blue-500/20 flex items-center justify-between p-4">
                    <div>
                        <h3 className="font-bold text-blue-400 text-sm">Find spots near you</h3>
                        <p className="text-xs text-blue-300/70">Enable location for the best experience.</p>
                    </div>
                    <button 
                        onClick={requestLocation}
                        className="px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-full shadow-lg active:scale-95 transition-transform"
                    >
                        Enable
                    </button>
                </GlassCard>
            )}

            {/* Loading State */}
            {loading && (
                <div className="space-y-8 animate-fade-in">
                    {[1, 2, 3].map(i => (
                        <div key={i} className="space-y-4">
                            <div className="flex items-center gap-3 px-2">
                                <div className="h-6 w-32 bg-surface-highlight rounded-md animate-pulse" />
                                <div className="h-px bg-surface-highlight flex-1"></div>
                            </div>
                            <CardSkeleton />
                        </div>
                    ))}
                </div>
            )}

            {/* Empty State */}
            {!loading && Object.keys(categorizedVenues).length === 0 && (
                <div className="flex flex-col items-center justify-center py-20 opacity-50 text-muted">
                    <span className="text-6xl mb-4">📡</span>
                    <h2 className="text-xl font-bold">No signal</h2>
                    <button onClick={requestLocation} className="mt-4 px-6 py-2 bg-surface-highlight rounded-full text-sm font-bold text-foreground">Retry</button>
                </div>
            )}

            {/* Categories */}
            {!loading && Object.keys(categorizedVenues).map((category) => (
                <section key={category}>
                    <div className="flex items-center gap-3 mb-4 px-2">
                        <h2 className="text-xl font-bold text-foreground">{category}</h2>
                        <div className="h-px bg-border flex-1"></div>
                    </div>
                    
                    <div className="flex flex-col gap-2">
                        {categorizedVenues[category].map((place, idx) => (
                            <NearbyVenueCard 
                                key={`${category}-${idx}`} 
                                place={place} 
                                index={idx}
                                registeredVenue={getRegisteredMatch(place)}
                                currency={uiContext.currencySymbol}
                                insight={venueInsights[place.name]}
                            />
                        ))}
                    </div>
                </section>
            ))}

            {/* Load More Button */}
            {!loading && hasMore && (
                <div className="py-4 flex justify-center">
                    <button 
                        onClick={handleLoadMore}
                        disabled={loadingMore}
                        className="px-8 py-3 bg-surface-highlight border border-border hover:bg-white/10 rounded-full text-sm font-bold flex items-center gap-2 transition-all active:scale-95 text-foreground"
                    >
                        {loadingMore ? <Spinner className="w-4 h-4" /> : 'Load More Venues'}
                    </button>
                </div>
            )}
            {!loading && !hasMore && allFetchedVenues.length >= MAX_VENUES && (
                <p className="text-center text-xs text-muted py-4">Maximum venues loaded.</p>
            )}

            {/* Quick Action */}
            <GlassCard className="bg-gradient-to-r from-blue-900/40 to-purple-900/40 border-blue-500/30 p-6 flex flex-col items-center text-center mt-8">
                <h3 className="font-bold text-xl mb-2 text-white">Already at a table?</h3>
                <p className="text-sm text-gray-200 mb-6">Scan the QR code on your table to skip the queue.</p>
                <button className="w-full py-4 bg-white text-black font-bold rounded-2xl shadow-xl active:scale-95 transition-transform flex items-center justify-center gap-2">
                    <span className="text-xl">📸</span> Scan QR Code
                </button>
            </GlassCard>
        </div>
      </PullToRefresh>
    </div>
  );
};

export default ClientHome;