import { supabase } from './supabase';
import { Venue, MenuItem, Order, OrderStatus, PaymentStatus, Table, Reservation, ReservationStatus, User, UserType, AdminUser, AuditLog } from '../types';

// --- PRODUCTION SERVICE LAYER ---
// Replaces previous mock implementation with direct, secure Supabase interactions.

// --- HELPERS ---

const handleSupabaseError = (error: any, context: string) => {
    console.error(`DB Error [${context}]:`, error);
    // specific error handling logic (e.g., toast notifications) could go here
    return null;
};

// --- MAPPERS ---
// Maps SQL snake_case to App camelCase

const mapVenue = (row: any): Venue => ({
  id: row.id,
  name: row.name,
  address: row.address,
  description: row.description,
  revolutHandle: row.revolut_handle,
  phone: row.phone,
  googleMapsUrl: row.google_maps_url,
  whatsappNumber: row.whatsapp_number,
  website: row.website,
  instagramUrl: row.instagram_url,
  facebookUrl: row.facebook_url,
  openingHours: row.opening_hours,
  tags: row.tags || [],
  menu: row.menu || [],
  imageUrl: row.image_url,
  ownerId: row.owner_id,
  currency: row.currency || '$',
  status: row.status || 'active'
});

const mapOrder = (row: any): Order => ({
  id: row.id,
  venueId: row.venue_id,
  tableNumber: row.table_number,
  orderCode: row.order_code,
  items: row.items || [],
  totalAmount: row.total_amount,
  currency: row.currency || '$',
  status: row.status as OrderStatus,
  paymentStatus: row.payment_status as PaymentStatus,
  timestamp: row.timestamp ? parseInt(row.timestamp) : Date.now(),
  customerNote: row.customer_note
});

const mapTable = (row: any): Table => ({
  id: row.id,
  venueId: row.venue_id,
  label: row.label,
  code: row.code,
  active: row.active
});

const mapReservation = (row: any): Reservation => ({
  id: row.id,
  venueId: row.venue_id,
  customerName: row.customer_name,
  partySize: row.party_size,
  dateTime: parseInt(row.date_time),
  status: row.status as ReservationStatus,
  createdAt: row.created_at,
  note: row.note
});

const mapUser = (row: any): User => ({
  id: row.id,
  name: row.name || 'Guest',
  role: (row.role as UserType) || UserType.CLIENT,
  favorites: row.favorites || [],
  notificationsEnabled: row.notifications_enabled ?? true
});

// --- CORE FUNCTIONS ---

// VENUES

export const getVenueById = async (id: string): Promise<Venue | undefined> => {
  const { data, error } = await supabase.from('venues').select('*').eq('id', id).single();
  if (error) return undefined;
  return mapVenue(data);
};

export const getVenueByOwner = async (ownerId: string): Promise<Venue | undefined> => {
    const { data, error } = await supabase.from('venues').select('*').eq('owner_id', ownerId).single();
    if (error || !data) return undefined;
    return mapVenue(data);
};

export const getAllVenues = async (): Promise<Venue[]> => {
  const { data, error } = await supabase.from('venues').select('*');
  if (error) handleSupabaseError(error, 'getAllVenues');
  return (data || []).map(mapVenue);
};

export const getFeaturedVenues = async (limit = 10): Promise<Venue[]> => {
    const { data, error } = await supabase.from('venues').select('*').eq('status', 'active').limit(limit);
    if (error) handleSupabaseError(error, 'getFeaturedVenues');
    return (data || []).map(mapVenue);
};

export const createVenue = async (venue: Venue): Promise<Venue> => {
  // We use the Edge Function for secure claiming (assigning owner_id securely)
  const { data, error } = await supabase.functions.invoke('business-logic', {
      body: { action: 'claim-venue', payload: venue }
  });
  
  if (error) {
      console.error("Function Error:", error);
      throw new Error("Failed to create venue via secure channel.");
  }
  return mapVenue(data);
};

export const updateVenue = async (venue: Venue): Promise<void> => {
  const dbVenue = {
      name: venue.name,
      address: venue.address,
      description: venue.description,
      revolut_handle: venue.revolutHandle,
      phone: venue.phone,
      whatsapp_number: venue.whatsappNumber,
      google_maps_url: venue.googleMapsUrl,
      website: venue.website,
      instagram_url: venue.instagramUrl,
      facebook_url: venue.facebookUrl,
      opening_hours: venue.openingHours,
      tags: venue.tags,
      menu: venue.menu, // JSONB
      image_url: venue.imageUrl,
      currency: venue.currency
  };
  
  const { error } = await supabase.from('venues').update(dbVenue).eq('id', venue.id);
  if (error) throw error;
};

export const updateVenueMenu = async (venueId: string, menu: MenuItem[]): Promise<void> => {
    const { error } = await supabase.from('venues').update({ menu: menu }).eq('id', venueId);
    if (error) throw error;
};

// ORDERS

export const createOrder = async (orderData: Partial<Order>): Promise<Order> => {
  // Call Edge Function to ensure secure order code generation and validation
  const { data, error } = await supabase.functions.invoke('business-logic', {
      body: { action: 'create-order', payload: orderData }
  });

  if (error) {
      // Offline Fallback: If function fails, try direct insert (less secure but keeps business running)
      // Note: RLS policy must allow 'insert' for public for this to work
      console.warn("Edge Function failed, attempting direct insert...", error);
      const fallbackCode = 'OFF-' + Math.random().toString(36).substr(2, 4).toUpperCase();
      const timestamp = Date.now();
      
      const { data: directData, error: directError } = await supabase
        .from('orders')
        .insert({ 
            ...orderData, 
            order_code: fallbackCode, 
            status: 'RECEIVED', 
            payment_status: 'UNPAID', 
            timestamp: timestamp 
        })
        .select()
        .single();
        
      if (directError) throw directError;
      return mapOrder(directData);
  }
  
  return mapOrder(data);
};

export const getOrdersForVenue = async (venueId: string): Promise<Order[]> => {
  const { data, error } = await supabase.from('orders').select('*').eq('venue_id', venueId);
  if (error) handleSupabaseError(error, 'getOrdersForVenue');
  return (data || []).map(mapOrder);
};

export const getAllOrders = async (): Promise<Order[]> => {
    const { data, error } = await supabase.from('orders').select('*');
    if (error) handleSupabaseError(error, 'getAllOrders');
    return (data || []).map(mapOrder);
}

export const updateOrderStatus = async (orderId: string, status: OrderStatus): Promise<void> => {
  const { error } = await supabase.from('orders').update({ status }).eq('id', orderId);
  if (error) throw error;
};

export const updatePaymentStatus = async (orderId: string, status: PaymentStatus): Promise<void> => {
  const { error } = await supabase.from('orders').update({ payment_status: status }).eq('id', orderId);
  if (error) throw error;
};

// ADMIN

export const adminSetVendorStatus = async (vendorId: string, status: 'active' | 'suspended') => {
    const { error } = await supabase.functions.invoke('business-logic', {
        body: { action: 'admin-update-status', payload: { venueId: vendorId, status } }
    });
    if (error) throw error;
};

// TABLES

export const getTablesForVenue = async (venueId: string): Promise<Table[]> => {
    const { data, error } = await supabase.from('tables').select('*').eq('venue_id', venueId);
    if (error) handleSupabaseError(error, 'getTables');
    return (data || []).map(mapTable);
};

export const createTablesBatch = async (venueId: string, count: number, startNum: number): Promise<void> => {
    const newTables = [];
    for(let i=0; i<count; i++) {
        const num = startNum + i;
        const suffix = Math.random().toString(36).substr(2, 6).toUpperCase();
        newTables.push({
            venue_id: venueId,
            label: `Table ${num}`,
            code: `T${num}-${suffix}`,
            active: true
        });
    }
    const { error } = await supabase.from('tables').insert(newTables);
    if (error) throw error;
};

export const deleteTable = async (tableId: string): Promise<void> => {
    const { error } = await supabase.from('tables').delete().eq('id', tableId);
    if (error) throw error;
};

export const updateTableStatus = async (tableId: string, active: boolean): Promise<void> => {
    const { error } = await supabase.from('tables').update({ active }).eq('id', tableId);
    if (error) throw error;
};

export const regenerateTableCode = async (tableId: string): Promise<void> => {
    const suffix = Math.random().toString(36).substr(2, 6).toUpperCase();
    const { data } = await supabase.from('tables').select('code').eq('id', tableId).single();
    if(data) {
        const prefix = data.code.split('-')[0];
        const { error } = await supabase.from('tables').update({ code: `${prefix}-${suffix}` }).eq('id', tableId);
        if (error) throw error;
    }
};

// RESERVATIONS

export const createReservation = async (resData: Partial<Reservation>): Promise<Reservation> => {
  const dbRes = {
    venue_id: resData.venueId,
    customer_name: resData.customerName || 'Anonymous',
    party_size: resData.partySize || 2,
    date_time: resData.dateTime || Date.now(),
    status: ReservationStatus.PENDING,
    note: resData.note
  };
  const { data, error } = await supabase.from('reservations').insert(dbRes).select().single();
  if (error) throw error;
  return mapReservation(data);
};

export const getReservationsForVenue = async (venueId: string): Promise<Reservation[]> => {
  const { data, error } = await supabase.from('reservations').select('*').eq('venue_id', venueId);
  if (error) handleSupabaseError(error, 'getReservations');
  return (data || []).map(mapReservation);
};

export const updateReservationStatus = async (id: string, status: ReservationStatus): Promise<void> => {
  const { error } = await supabase.from('reservations').update({ status }).eq('id', id);
  if (error) throw error;
};

// USER PROFILES

export const getMyProfile = async (): Promise<User> => {
  const { data: { user } } = await supabase.auth.getUser();
  // Return guest structure if no user
  if (!user) return { id: 'guest', name: 'Guest', role: UserType.CLIENT, favorites: [], notificationsEnabled: true };
  
  const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
  
  if (error || !data) {
      // If profile doesn't exist (first time), create it
      const newP = { id: user.id, name: 'Guest', role: 'CLIENT' };
      const { error: insertError } = await supabase.from('profiles').insert(newP);
      if (insertError) console.error("Error creating profile", insertError);
      return mapUser(newP);
  }
  return mapUser(data);
};

export const updateMyProfile = async (updates: Partial<User>): Promise<User> => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return updates as User; // Cannot update guest
  
  const dbUpdates: any = {};
  if (updates.name) dbUpdates.name = updates.name;
  if (updates.role) dbUpdates.role = updates.role;
  if (updates.favorites) dbUpdates.favorites = updates.favorites;
  if (updates.notificationsEnabled !== undefined) dbUpdates.notifications_enabled = updates.notificationsEnabled;
  
  const { data, error } = await supabase.from('profiles').update(dbUpdates).eq('id', user.id).select().single();
  if (error) throw error;
  return mapUser(data);
};

export const toggleFavoriteVenue = async (venueId: string): Promise<string[]> => {
    const p = await getMyProfile();
    let favs = p.favorites || [];
    if (favs.includes(venueId)) favs = favs.filter(f => f !== venueId);
    else favs.push(venueId);
    await updateMyProfile({ favorites: favs });
    return favs;
};

// ADMIN & AUDIT

export const checkIsAdmin = async (email: string): Promise<boolean> => {
    const { data } = await supabase.from('admin_users').select('*').eq('email', email).eq('is_active', true).single();
    return !!data;
};

export const getAdminUsers = async (): Promise<AdminUser[]> => {
    const { data, error } = await supabase.from('admin_users').select('*');
    if (error) handleSupabaseError(error, 'getAdminUsers');
    return (data || []).map(r => ({ id: r.id, authUserId: r.auth_user_id, email: r.email, role: r.role, isActive: r.is_active, createdAt: new Date(r.created_at).getTime() }));
};

export const getAuditLogs = async (): Promise<AuditLog[]> => {
    const { data, error } = await supabase.from('audit_logs').select('*').order('created_at', { ascending: false });
    if (error) handleSupabaseError(error, 'getAuditLogs');
    return (data || []).map(r => ({ id: r.id, actorId: r.actor_auth_user_id, action: r.action, entityType: r.entity_type, entityId: r.entity_id, metadata: r.metadata_json, createdAt: new Date(r.created_at).getTime() }));
};

export const getAllUsers = async (): Promise<User[]> => {
    const { data, error } = await supabase.from('profiles').select('*');
    if (error) handleSupabaseError(error, 'getAllUsers');
    return (data || []).map(mapUser);
};
