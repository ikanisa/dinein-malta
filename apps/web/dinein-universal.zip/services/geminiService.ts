import { supabase } from './supabase';
import { getFeaturedVenues } from './mockDatabase';

// --- DEV MODE CONFIG ---
const STORAGE_KEY = 'dinein_live_ai_mode';
let LIVE_AI_MODE = localStorage.getItem(STORAGE_KEY) === 'true';

export const setLiveAiMode = (enable: boolean) => {
    LIVE_AI_MODE = enable;
    localStorage.setItem(STORAGE_KEY, String(enable));
    console.log(`[GeminiService] AI Mode switched to: ${enable ? 'LIVE (Real Costs)' : 'MOCK (DB Fallback)'}`);
};

export const isLiveAiMode = () => LIVE_AI_MODE;

// Helper to call Edge Function
const invokeGemini = async (action: string, payload: any) => {
    if (!LIVE_AI_MODE) throw new Error('Mock Mode Active');
    const { data, error } = await supabase.functions.invoke('gemini-features', {
        body: { action, payload }
    });
    if (error) throw error;
    return data;
};

// --- 1. SEARCH GROUNDING (Market Intelligence & Events) ---

export const getMarketInsights = async (category: string) => {
    if (!LIVE_AI_MODE) return { text: `(AI Mode Off) Please enable Live AI to fetch real-time market trends for ${category}.`, sources: [] };
    try {
        return await invokeGemini('market-insights', { category });
    } catch (e) {
        console.error(e);
        return { text: "Unable to fetch market insights.", sources: [] };
    }
};

export const getVenueInsights = async (venueNames: string[], lat: number, lng: number) => {
    if (!LIVE_AI_MODE || venueNames.length === 0) return {};
    try {
        return await invokeGemini('venue-insights', { names: venueNames, lat, lng });
    } catch (e) {
        console.error("Insight fetch failed", e);
        return {};
    }
};

// --- 2. MAPS GROUNDING (Discovery) ---

export const findVenuesForClaiming = async (lat: number, lng: number) => {
  if (!LIVE_AI_MODE) return []; // Cannot discover real unclaimed places without API
  try {
      return await invokeGemini('discover', { lat, lng });
  } catch (e) {
      console.error(e);
      return [];
  }
};

// --- 3. IMAGE GENERATION ---

export const generateProImage = async (prompt: string, size: '1K' | '2K' | '4K' = '1K'): Promise<string | null> => {
    if (!LIVE_AI_MODE) return null; // No generation without live mode
    try {
        return await invokeGemini('generate-image', { prompt, size, model: 'gemini-3-pro-image-preview' });
    } catch (e) {
        console.error(e);
        return null;
    }
};

export const editImageWithAi = async (base64Data: string, mimeType: string, editPrompt: string): Promise<string | null> => {
    if (!LIVE_AI_MODE) return base64Data;
    try {
        return await invokeGemini('edit-image', { image: base64Data, prompt: editPrompt });
    } catch (e) {
        console.error(e);
        return null;
    }
};

// --- 4. TEXT INTELLIGENCE ---

export const generateSmartDescription = async (itemName: string, category: string) => {
    if (!LIVE_AI_MODE) return "";
    try {
        return await invokeGemini('smart-description', { name: itemName, category });
    } catch (e) {
        return "";
    }
}

export const adaptUiToLocation = async (lat: number, lng: number) => {
    if (!LIVE_AI_MODE) return { appName: "DineIn Malta", greeting: "Welcome", currencySymbol: "€", visualVibe: "Mediterranean" };
    try {
        const res = await invokeGemini('adapt', { lat, lng });
        return {
            appName: `DineIn ${res.cityName || 'Malta'}`,
            greeting: res.greeting || "Welcome",
            currencySymbol: res.currencySymbol || "€",
            visualVibe: `${res.cityName}, ${res.country}`
        };
    } catch (e) {
        return { appName: "DineIn Malta", greeting: "Welcome", currencySymbol: "€" };
    }
};

export const searchPlacesByName = async (query: string, lat?: number, lng?: number) => {
    if (!LIVE_AI_MODE) return [];
    try {
        // Fallback to Malta coords if user location unknown (Valletta approx)
        const searchLat = lat || 35.8989;
        const searchLng = lng || 14.5146;
        return await invokeGemini('search', { query, lat: searchLat, lng: searchLng });
    } catch (e) { return []; }
}

export const enrichVenueProfile = async (name: string, address: string) => {
    if (!LIVE_AI_MODE) return {};
    try {
        return await invokeGemini('enrich-profile', { name, address });
    } catch (e) { return {}; }
}

export const parseMenuFromFile = async (base64Data: string, mimeType: string) => {
  if (!LIVE_AI_MODE) return [];
  try {
      return await invokeGemini('parse-menu', { fileData: base64Data, mimeType });
  } catch (e) { return []; }
};

export const generateVenueThumbnail = async (venueName: string, vibe: string): Promise<string | null> => {
    if (!LIVE_AI_MODE) return null;

    const cacheKey = `venue_thumb_${venueName.replace(/\s/g,'')}`;
    const local = localStorage.getItem(cacheKey);
    if(local) return local;

    try {
        const url = await invokeGemini('generate-image', { prompt: `Cinematic photo of ${venueName} in Malta. Style: ${vibe}.`, model: 'gemini-2.5-flash-image' });
        if(url) localStorage.setItem(cacheKey, url);
        return url;
    } catch (e) { return null; }
};

export const generateMenuItemImage = async (itemName: string, description: string): Promise<string | null> => {
    if (!LIVE_AI_MODE) return null;
    // Use gemini-2.5-flash-image (Nano Banana) for menu items as requested for efficiency
    return await invokeGemini('generate-image', { 
        prompt: `Professional appetizing food photography of ${itemName}. ${description}. Centered, restaurant menu style.`, 
        model: 'gemini-2.5-flash-image' 
    });
};

export const findNearbyPlaces = async (lat: number, lng: number, excludeNames: string[] = []) => {
  // If AI is off or fails, fallback to retrieving real active venues from the DB
  if (!LIVE_AI_MODE) {
      const dbVenues = await getFeaturedVenues(10);
      return dbVenues.filter(v => !excludeNames.includes(v.name));
  }
  
  try {
      return await invokeGemini('discover', { lat, lng });
  } catch (e) { 
      // Fallback on error
      const dbVenues = await getFeaturedVenues(5);
      return dbVenues; 
  }
};

export const discoverGlobalVenues = async () => {
    // If AI is off, show real venues from our platform DB
    if (!LIVE_AI_MODE) {
        return await getFeaturedVenues(10);
    }
    try {
        // Bias towards Malta for the "Global" fallback
        return await invokeGemini('search', { query: "popular bars and restaurants in Malta" });
    } catch(e) { 
        return await getFeaturedVenues(10); 
    }
};

export const getAiRecommendation = async (userQuery: string, userLocation?: {lat: number, lng: number}) => {
    if (!LIVE_AI_MODE) return { text: "AI Mode is disabled. Enable it in Dev settings to use the Concierge.", chunks: [] };
    try {
        return await invokeGemini('recommend', { query: userQuery, location: userLocation });
    } catch (error) { return { text: "Concierge offline.", chunks: [] }; }
};