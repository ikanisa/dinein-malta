import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import ClientHome from './pages/ClientHome';
import ClientMenu from './pages/ClientMenu';
import ClientExplore from './pages/ClientExplore';
import ClientProfile from './pages/ClientProfile';
import VendorLogin from './pages/VendorLogin';
import VendorOnboarding from './pages/VendorOnboarding';
import VendorDashboard from './pages/VendorDashboard';
import DeveloperSwitchboard from './pages/DeveloperSwitchboard';
import AdminDashboard from './pages/AdminDashboard';
import AdminUsers from './pages/AdminUsers'; 
import AdminLogin from './pages/AdminLogin';
import AdminVendors from './pages/AdminVendors';
import AdminOrders from './pages/AdminOrders';
import AdminSystem from './pages/AdminSystem';
import { supabase } from './services/supabase';
import { ThemeProvider } from './context/ThemeContext';
import { CartProvider, useCart } from './context/CartContext';
import { GlassCard } from './components/GlassCard';

// --- UTILS ---
const vibrate = () => {
    if (navigator.vibrate) navigator.vibrate(10);
};

// --- COMPONENTS ---

const OfflineIndicator = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[100] bg-red-600 text-white text-xs font-bold text-center py-1 animate-pulse">
      ⚠️ You are currently offline. Orders will sync when online.
    </div>
  );
};

const InstallPrompt = () => {
  const [show, setShow] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // 1. Robust iOS Check (handles iPads requesting desktop sites)
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIosDevice = /iphone|ipad|ipod/.test(userAgent) || 
                       (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    
    // 2. Check if already standalone (installed)
    const isStandalone = ('standalone' in window.navigator && (window.navigator as any).standalone) || 
                         window.matchMedia('(display-mode: standalone)').matches;

    if (isStandalone) return;

    if (isIosDevice) {
      setIsIOS(true);
      // Show iOS prompt after a short delay if not previously dismissed
      if (!localStorage.getItem('pwa-prompt-dismissed')) {
        setTimeout(() => setShow(true), 3000);
      }
    } else {
      // Android/Desktop standard mechanism
      const handler = (e: any) => {
        e.preventDefault();
        setDeferredPrompt(e);
        if (!localStorage.getItem('pwa-prompt-dismissed')) {
          setShow(true);
        }
      };
      window.addEventListener('beforeinstallprompt', handler);
      return () => window.removeEventListener('beforeinstallprompt', handler);
    }
  }, []);

  const handleInstall = () => {
    if (isIOS) {
        // Just dismiss, we can't programmatically install on iOS.
        setShow(false);
        localStorage.setItem('pwa-prompt-dismissed', 'true');
    } else if (deferredPrompt) {
      vibrate();
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          localStorage.setItem('pwa-prompt-dismissed', 'true');
        }
        setDeferredPrompt(null);
        setShow(false);
      });
    }
  };

  const handleDismiss = () => {
      setShow(false);
      localStorage.setItem('pwa-prompt-dismissed', 'true');
  };

  if (!show) return null;

  // iOS Native-like Modal
  if (isIOS) {
    return (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-end sm:items-center justify-center p-4 animate-fade-in" onClick={handleDismiss}>
            <GlassCard 
                className="w-full max-w-sm p-6 bg-surface shadow-2xl border-blue-500/20 relative animate-slide-up" 
                onClick={(e) => e.stopPropagation()}
            >
                <button onClick={handleDismiss} className="absolute top-4 right-4 text-muted hover:text-foreground">✕</button>
                <div className="flex flex-col items-center text-center mb-6">
                     <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center text-white font-bold text-3xl shadow-lg mb-4">D</div>
                     <h3 className="text-xl font-bold text-foreground">Install DineIn</h3>
                     <p className="text-sm text-muted">Add to your Home Screen for the best experience.</p>
                </div>
                
                <div className="space-y-4 text-left">
                    <div className="flex items-center gap-4 bg-surface-highlight p-3 rounded-xl border border-border">
                        <span className="text-2xl text-blue-500 flex items-center justify-center w-10">
                             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                        </span>
                        <div>
                            <div className="text-xs text-muted font-bold uppercase">Step 1</div>
                            <div className="text-sm font-medium">Tap the <span className="font-bold">Share</span> button in your browser bar.</div>
                        </div>
                    </div>
                     <div className="flex items-center gap-4 bg-surface-highlight p-3 rounded-xl border border-border">
                        <span className="text-2xl text-foreground flex items-center justify-center w-10">⊞</span>
                        <div>
                            <div className="text-xs text-muted font-bold uppercase">Step 2</div>
                            <div className="text-sm font-medium">Scroll down and select <span className="font-bold">Add to Home Screen</span>.</div>
                        </div>
                    </div>
                </div>
                
                <button onClick={handleDismiss} className="w-full mt-6 py-3 bg-foreground text-background font-bold rounded-xl shadow-lg">Got it</button>
            </GlassCard>
            {/* Hint arrow for bottom bar */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white animate-bounce sm:hidden pointer-events-none text-2xl drop-shadow-md">
                👇
            </div>
        </div>
    );
  }

  // Android/Desktop Prompt
  return (
    <motion.div 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      className="fixed bottom-24 left-4 right-4 z-[60] md:left-auto md:right-8 md:w-96"
    >
      <GlassCard className="flex flex-col gap-4 shadow-2xl border-blue-500/30 relative overflow-hidden backdrop-blur-xl bg-surface/90">
        <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg">
                    D
                </div>
                <div>
                    <h3 className="font-bold text-base text-foreground">Install DineIn</h3>
                    <p className="text-xs text-muted">Add to home screen for quick access.</p>
                </div>
            </div>
            <button onClick={handleDismiss} className="p-1 text-muted hover:text-foreground transition-colors bg-surface-highlight rounded-full">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M18 6L6 18M6 6l12 12" />
                </svg>
            </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
            <button onClick={handleDismiss} className="py-3 text-xs font-bold text-muted bg-surface-highlight hover:bg-black/5 dark:hover:bg-white/10 rounded-xl transition-colors">
                Not Now
            </button>
            <button onClick={handleInstall} className="py-3 text-xs font-bold bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg shadow-blue-500/20 transition-all active:scale-95 flex items-center justify-center gap-2">
                Install App
            </button>
        </div>
      </GlassCard>
    </motion.div>
  );
};

const DevButton = () => {
  const navigate = useNavigate();
  const location = useLocation();
  if (location.pathname === '/dev') return null;
  return (
    <button 
      onClick={() => { vibrate(); navigate('/dev'); }}
      className="fixed top-safe right-4 z-[70] bg-black/40 backdrop-blur-md border border-white/10 text-white/30 hover:text-white text-[10px] px-2 py-0.5 rounded-full hover:bg-black/60 transition-colors mt-2"
    >
      DEV
    </button>
  );
};

const AnimatedRoutes = () => {
  const location = useLocation();
  
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, x: 10 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -10 }}
        transition={{ duration: 0.2 }}
        className="min-h-full"
      >
        <Routes location={location}>
            {/* Client Routes */}
            <Route path="/" element={<ClientHome />} />
            <Route path="/explore" element={<ClientExplore />} />
            <Route path="/profile" element={<ClientProfile />} />
            <Route path="/menu/:venueId" element={<ClientMenu />} />
            <Route path="/v/:venueId/t/:tableId" element={<ClientMenu />} />

            {/* Vendor Routes */}
            <Route path="/business" element={<VendorLogin />} />
            <Route path="/vendor-login" element={<VendorLogin />} />
            <Route path="/vendor-onboarding" element={<VendorOnboarding />} />
            <Route path="/vendor-dashboard" element={<VendorDashboard />} />
            <Route path="/vendor-dashboard/:tab" element={<VendorDashboard />} />

            {/* Admin Routes */}
            <Route path="/admin-login" element={<AdminLogin />} />
            <Route path="/admin-dashboard" element={<AdminDashboard />} />
            <Route path="/admin-vendors" element={<AdminVendors />} />
            <Route path="/admin-orders" element={<AdminOrders />} />
            <Route path="/admin-system" element={<AdminSystem />} />
            <Route path="/admin-users" element={<AdminUsers />} />

            {/* Dev */}
            <Route path="/dev" element={<DeveloperSwitchboard />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
};

// Layout Shell
const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="fixed inset-0 w-full h-[100dvh] overflow-hidden bg-background text-foreground flex flex-col transition-colors duration-500">
      <OfflineIndicator />
      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            background: 'var(--bg-surface)',
            color: 'var(--text-main)',
            border: '1px solid var(--border-color)',
            backdropFilter: 'blur(10px)',
          }
        }} 
      />
      
      <div 
        id="main-scroll"
        className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar pb-safe-bottom pt-safe-top"
        style={{ WebkitOverflowScrolling: 'touch' }}
      >
          {children}
      </div>
      
      <InstallPrompt />
      <DevButton />
      <BottomNavigation />
    </div>
  );
};

const BottomNavigation = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const path = location.pathname;
    const { totalItems } = useCart(); // Now using the correct hook
    
    // Only vibrate on nav change if it's a direct user interaction handled by NavBtn
    const handleNav = (p: string) => {
        if (path !== p) {
            vibrate();
            navigate(p);
        }
    };

    if (path === '/dev' || path === '/vendor-onboarding' || path === '/vendor-login' || path === '/business' || path === '/admin-login') return null;

    if (path.startsWith('/admin')) {
        return (
            <div className="absolute bottom-6 left-0 right-0 flex justify-center z-50 pointer-events-none">
                <GlassCard className="rounded-full px-6 py-4 flex gap-8 pointer-events-auto bg-black/60 backdrop-blur-xl border-red-500/20 shadow-2xl" noPadding>
                    <NavBtn icon="📊" label="Dash" active={path === '/admin-dashboard'} onClick={() => handleNav('/admin-dashboard')} />
                    <NavBtn icon="🏪" label="Vendors" active={path === '/admin-vendors'} onClick={() => handleNav('/admin-vendors')} />
                    <NavBtn icon="🧾" label="Orders" active={path === '/admin-orders'} onClick={() => handleNav('/admin-orders')} />
                </GlassCard>
            </div>
        );
    }

    if (path.startsWith('/vendor') || path.startsWith('/v/')) { 
        return (
            <div className="absolute bottom-6 left-0 right-0 flex justify-center z-50 pointer-events-none">
                <GlassCard className="rounded-full px-6 py-4 flex gap-8 pointer-events-auto shadow-2xl" noPadding>
                    <NavBtn icon="🔔" label="Orders" active={path === '/vendor-dashboard/orders' || path === '/vendor-dashboard'} onClick={() => handleNav('/vendor-dashboard/orders')} />
                    <NavBtn icon="🍔" label="Menu" active={path === '/vendor-dashboard/menu'} onClick={() => handleNav('/vendor-dashboard/menu')} />
                    <NavBtn icon="🏁" label="Tables" active={path === '/vendor-dashboard/tables'} onClick={() => handleNav('/vendor-dashboard/tables')} />
                    <NavBtn icon="⚙️" label="Settings" active={path === '/vendor-dashboard/settings'} onClick={() => handleNav('/vendor-dashboard/settings')} />
                </GlassCard>
            </div>
        );
    }

    return (
        <div className="absolute bottom-6 left-4 right-4 z-50 pointer-events-none">
             <GlassCard className="rounded-2xl p-1 pointer-events-auto mx-auto max-w-sm shadow-2xl border-border" noPadding>
                <div className="flex justify-around items-center h-16">
                    <NavBtn icon="🏠" label="Home" active={path === '/'} onClick={() => handleNav('/')} />
                    <NavBtn icon="🧭" label="Explore" active={path === '/explore'} onClick={() => handleNav('/explore')} />
                    <NavBtn icon="👤" label="Profile" active={path === '/profile'} onClick={() => handleNav('/profile')} />
                </div>
             </GlassCard>
        </div>
    );
};

const NavBtn = ({ icon, label, active, onClick }: { icon: string, label: string, active: boolean, onClick: () => void }) => (
    <button 
        onClick={onClick} 
        className={`flex-1 flex flex-col items-center justify-center gap-1 h-full rounded-xl transition-all duration-300 ${active ? 'bg-surface-highlight text-foreground' : 'text-muted hover:text-foreground'}`}
    >
        <motion.span 
          animate={active ? { scale: 1.2, y: -2 } : { scale: 1, y: 0 }}
          className="text-2xl"
        >
          {icon}
        </motion.span>
        {active && (
          <motion.span initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-[10px] font-bold tracking-wide">
            {label}
          </motion.span>
        )}
    </button>
);

const App = () => {
  useEffect(() => {
    const initAuth = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
          await supabase.auth.signInAnonymously();
        }
      } catch (e) { console.error(e); }
    };
    initAuth();
  }, []);

  return (
    <ThemeProvider>
      <CartProvider>
        <Router>
            <Layout>
            <AnimatedRoutes />
            </Layout>
        </Router>
      </CartProvider>
    </ThemeProvider>
  );
};

export default App;